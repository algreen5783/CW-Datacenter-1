# Build CW Datacenter iOS 1.6.9

## Build IPA bằng GitHub Actions (không cần máy Mac)

### Dùng với repository CW-Datacenter-iP hiện tại

1. Upload nguyên file `CW-Datacenter-iOS-1.6.9-GitHub-IPA-Build.zip` vào thư mục gốc của repository nếu repository của bạn có bước tự giải nén; hoặc giải nén và upload toàn bộ nội dung vào gốc repo mới.
2. Gói ZIP đã có thư mục cấp cao nhất `ios/`, đúng với workflow hiện tại đang chạy `cd ios`.
3. Mở tab **Actions** > **Build iOS App (.ipa)** > **Run workflow** nếu lượt chạy không tự xuất hiện sau khi upload.
4. Khi job hoàn tất, tải artifact `CW-Datacenter-iOS-1.4.0`.

Artifact vẫn chứa `CW-Datacenter-iOS-1.4.0-unsigned.ipa` để tương thích workflow cũ. Phiên bản thực bên trong app là `1.6.9` (build `10609`).

Workflow hiện tại giải nén tất cả file ZIP ở root theo thứ tự tên. Nên xóa các gói build iOS cũ khỏi repository sau khi đã có bản sao lưu, chỉ giữ gói mới nhất để tránh source cũ ghi đè lẫn nhau.

IPA từ workflow là bản **unsigned**. Cần ký bằng chứng chỉ/provisioning profile của bạn trước khi cài lên iPhone, hoặc dùng công cụ sideload có hỗ trợ ký.

## Build/ký bằng Xcode

1. Mở `CWDatacenter.xcodeproj` bằng Xcode.
2. Chọn target **CWDatacenter** > **Signing & Capabilities**.
3. Chọn Team và Bundle Identifier thuộc tài khoản Apple Developer của bạn.
4. Chọn thiết bị hoặc **Any iOS Device (arm64)** rồi **Product > Archive**.
5. Trong Organizer, dùng **Distribute App** để xuất IPA đã ký.

## Kiểm tra bắt buộc

- Phiên bản app: `1.6.9` (build `10609`).
- Trong app bundle phải có `Web/index.html` và `Web/app.js`, đều mang marker `1.6.9`.
- Trong `PlugIns` phải có `CWDatacenterShare.appex` để app xuất hiện trong bảng Chia sẻ ảnh/video.
- Quyền Photos và Local Network phải còn trong `Info.plist`.
- Lần đầu dùng Đồng bộ, cấp quyền **Tất cả ảnh** (hoặc lựa chọn ảnh mong muốn nếu dùng quyền giới hạn).

Xem chi tiết thay đổi trong `CHANGELOG-1.6.9.md`.
