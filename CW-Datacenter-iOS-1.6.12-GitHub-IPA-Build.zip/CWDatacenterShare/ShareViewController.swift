import UIKit
import UniformTypeIdentifiers

final class ShareViewController: UIViewController {
    private let statusLabel = UILabel()
    private var started = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        statusLabel.numberOfLines = 0
        statusLabel.textAlignment = .center
        statusLabel.font = .systemFont(ofSize: 16, weight: .semibold)
        statusLabel.text = "Đang thêm vào CW Datacenter…"
        view.addSubview(statusLabel)
        NSLayoutConstraint.activate([
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            statusLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard !started else { return }
        started = true
        importAttachments()
    }

    private func importAttachments() {
        guard let root = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: "group.com.cw.datacenter.ios") else {
            finish("Không mở được vùng chia sẻ của CW Datacenter.")
            return
        }
        let inbox = root.appendingPathComponent("IncomingShares", isDirectory: true)
        do { try FileManager.default.createDirectory(at: inbox, withIntermediateDirectories: true) }
        catch { finish("Không tạo được hàng chờ chia sẻ."); return }

        let providers = (extensionContext?.inputItems as? [NSExtensionItem] ?? []).flatMap { $0.attachments ?? [] }
        let accepted = providers.filter {
            $0.hasItemConformingToTypeIdentifier(UTType.image.identifier) ||
            $0.hasItemConformingToTypeIdentifier(UTType.movie.identifier)
        }
        guard !accepted.isEmpty else { finish("Không có ảnh hoặc video phù hợp."); return }

        let group = DispatchGroup()
        let lock = NSLock()
        var copied = 0
        for provider in accepted {
            let type = provider.hasItemConformingToTypeIdentifier(UTType.movie.identifier) ? UTType.movie.identifier : UTType.image.identifier
            group.enter()
            provider.loadFileRepresentation(forTypeIdentifier: type) { url, _ in
                defer { group.leave() }
                guard let source = url else { return }
                let original = provider.suggestedName ?? source.lastPathComponent
                let clean = original.replacingOccurrences(of: "/", with: "_")
                let ext = source.pathExtension
                let hasExt = clean.contains(".")
                let name = UUID().uuidString + "_" + clean + ((!hasExt && !ext.isEmpty) ? ".\(ext)" : "")
                let target = inbox.appendingPathComponent(name)
                do {
                    try FileManager.default.copyItem(at: source, to: target)
                    lock.lock(); copied += 1; lock.unlock()
                } catch {}
            }
        }
        group.notify(queue: .main) { [weak self] in
            self?.finish(copied > 0 ? "Đã thêm \(copied) tệp. Mở CW Datacenter, chọn thư mục Host để tải lên." : "Không sao chép được ảnh/video.")
        }
    }

    private func finish(_ text: String) {
        statusLabel.text = text
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { [weak self] in
            self?.extensionContext?.completeRequest(returningItems: nil)
        }
    }
}
