﻿import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        AppLogger.shared.bootstrap()
        AppLogger.shared.log(.info, category: "LIFECYCLE", "didFinishLaunching")
        if #available(iOS 13.0, *) {
            // SceneDelegate handles UI on iOS 13+
        } else {
            let win = UIWindow(frame: UIScreen.main.bounds)
            win.rootViewController = MainViewController()
            win.makeKeyAndVisible()
            self.window = win
        }
        return true
    }

    func applicationDidReceiveMemoryWarning(_ application: UIApplication) {
        AppLogger.shared.log(.warning, category: "MEMORY", "iOS gửi cảnh báo bộ nhớ thấp")
    }

    func applicationWillTerminate(_ application: UIApplication) {
        AppLogger.shared.markCleanTermination()
    }

    // MARK: UISceneSession Lifecycle
    @available(iOS 13.0, *)
    func application(
        _ application: UIApplication,
        configurationForConnecting connectingSceneSession: UISceneSession,
        options: UIScene.ConnectionOptions
    ) -> UISceneConfiguration {
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
}
