﻿import UIKit

@available(iOS 13.0, *)
class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(
        _ scene: UIScene,
        willConnectTo session: UISceneSession,
        options connectionOptions: UIScene.ConnectionOptions
    ) {
        AppLogger.shared.log(.info, category: "LIFECYCLE", "Scene kết nối")
        guard let windowScene = (scene as? UIWindowScene) else { return }
        let win = UIWindow(windowScene: windowScene)
        win.rootViewController = MainViewController()
        win.makeKeyAndVisible()
        self.window = win
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        AppLogger.shared.log(.debug, category: "LIFECYCLE", "Ứng dụng active")
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        AppLogger.shared.log(.info, category: "LIFECYCLE", "Ứng dụng vào nền")
    }
}
