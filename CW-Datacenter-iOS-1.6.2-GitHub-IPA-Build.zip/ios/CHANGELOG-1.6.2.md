# CW Datacenter iOS 1.6.2

- Thêm công tắc `Xóa khỏi iPhone sau khi upload` trong tab Đồng bộ.
- Công tắc mặc định tắt và được lưu riêng theo từng Host.
- Khi tắt, ảnh/video gốc luôn được giữ trên iPhone sau khi upload.
- Khi bật, app chỉ chuyển ảnh/video vào `Đã xóa gần đây` sau khi Host xác minh đủ toàn bộ file của phiên đồng bộ.
- Không xóa khi upload dở dang, mất kết nối, sai kích thước, còn file chưa xác minh hoặc phiên đồng bộ thất bại.
- Các file đã đồng bộ từ phiên trước chỉ được đưa vào hàng xóa khi công tắc đang bật và Host vẫn xác minh đúng kích thước.
- Phiên bản app `1.6.2`, build `10602`; tên IPA đầu ra cố định vẫn được giữ để tương thích pipeline GitHub hiện tại.
