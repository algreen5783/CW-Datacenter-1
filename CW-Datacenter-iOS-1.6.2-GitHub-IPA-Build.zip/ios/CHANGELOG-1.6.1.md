# CW Datacenter iOS 1.6.1

- Thêm ô đặt tên thư mục thiết bị trong tab Đồng bộ; tên được lưu riêng theo từng Host.
- Ảnh và video mới nằm trong `<tên thiết bị>/Camera_1`, `Camera_2`... với tối đa 200 tệp mỗi thư mục.
- Ngừng phân tán file mới theo hash vào 256 thư mục `Camera_x`; vẫn nhận diện dữ liệu 1.6.0 cũ để tránh upload trùng.
- Danh sách "Đã đẩy lên máy chủ gần đây" cập nhật ngay sau từng file upload thành công, không cần đổi tab.
- Khi đọc iCloud hoặc upload Host lỗi, phiên đồng bộ dừng tại đúng file đó thay vì bỏ qua rồi nhảy sang file tiếp theo.
- Record chỉ được ghi sau khi Host hoàn tất upload, giữ khả năng tiếp tục đúng file ở lần Đồng bộ sau.
- Giữ tương thích iOS 14 cho các nút trong trình xem ảnh.
- Phiên bản app `1.6.1`, build `10601`; tên IPA đầu ra cố định vẫn được giữ để tương thích pipeline GitHub hiện tại.
