# CW Datacenter iOS 1.5.8

- Xóa mục "Thư mục mới" khỏi bảng tác vụ của từng tệp/thư mục.
- Thêm mục "Thông tin" cho tệp và thư mục trên Host lẫn ổ "Thiết bị này".
- Hiển thị dung lượng, vị trí, loại, số tệp/thư mục và thời gian chỉnh sửa.
- Dung lượng thư mục trên Host dùng API của Host 1.5.9; dung lượng thư mục cục bộ được quét đệ quy trong vùng lưu trữ của ứng dụng.
