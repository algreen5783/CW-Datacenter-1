# CW Datacenter iOS 1.6.0

- Không tự động upload thư viện khi mở app; chỉ đồng bộ sau khi người dùng nhấn nút.
- Thêm ba chế độ: Ảnh và video, Chỉ ảnh, Chỉ video.
- Khóa nguyên tử một phiên camera backup để ngăn nhiều lượt chạy chồng nhau.
- Dùng định danh PHAsset ổn định trong tên/nhóm file mới, không còn phụ thuộc vị trí media trong thư viện.
- Giữ tương thích và nhận diện file do các bản 1.5.9 trở về trước đã upload.
- Đối chiếu đường dẫn và dung lượng record đã xác minh trước khi bỏ qua upload.
- Quét lại Host trước khi thông báo đã đồng bộ toàn bộ.
- Không ép giao diện thành 100% nếu Host vẫn còn thiếu file.
- Sửa nháy tab Đồng bộ bằng cách chỉ cập nhật các thành phần tiến độ thay vì dựng lại toàn bộ danh sách.
- Mở rộng vùng bấm nút quay lại và căn giữa biểu tượng mũi tên.
- Khôi phục tên đầu ra GitHub cố định `CW-Datacenter-iOS-1.4.0-unsigned.ipa` để tương thích pipeline cũ; phiên bản thực bên trong app vẫn là `1.6.0` (build `10600`).
- Đóng gói lại source dưới thư mục cấp cao nhất `ios/` để tương thích workflow `build-ios.yml` hiện tại của repository CW-Datacenter-iP.
- Sửa lỗi build với deployment target iOS 14: trình xem ảnh chỉ dùng `UIButton.Configuration` trên iOS 15 trở lên và có giao diện tương thích riêng cho iOS 14.
