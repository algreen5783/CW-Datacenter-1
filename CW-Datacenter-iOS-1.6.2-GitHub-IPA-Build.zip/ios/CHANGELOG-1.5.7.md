# CW Datacenter iOS 1.5.7

- Transfer bị lỗi hiển thị nút `↻ Thử lại` ngay trên thẻ lỗi.
- Hỗ trợ thử lại upload, download, file cục bộ và đồng bộ thư viện PhotoKit.
- Khi thử lại, mục tự chuyển về tab Đang chạy và dùng token đăng nhập hiện tại.
- Giữ phần trăm thực tế khi lỗi thay vì tô thanh tiến độ thành 100%.
- Không thay đổi source Android, TV hoặc Windows.
