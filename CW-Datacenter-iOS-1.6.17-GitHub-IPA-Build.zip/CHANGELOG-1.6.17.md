# CW Datacenter iOS 1.6.17

- Sửa workflow GitHub Actions bị Xcode 16.4 thoát với mã 65 nhưng không in lỗi biên dịch.
- Chỉ định rõ generic iOS destination và giới hạn một build worker để app/Share Extension không tranh chấp tiến trình.
- Tắt build song song ở project và shared scheme để Share Extension hoàn tất trước app chính.
- Tách clean/build và bổ sung artifact chẩn đoán gồm log đầy đủ cùng `.xcresult`.
- Giữ nguyên toàn bộ chức năng và giao diện của iOS 1.6.16.
- Giữ tên IPA tương thích `CW-Datacenter-iOS-1.4.0-unsigned.ipa`; phiên bản trong app là 1.6.17 (10617).
