# CW Datacenter iOS 1.6.22

- Thêm bộ icon định dạng file đồng nhất với Android và Windows.
- Nhận diện tài liệu Office/OpenDocument, media, archive, code, database, ebook, font, thiết kế, AI và gói APK/IPA/desktop.
- Cập nhật workflow build IPA lên phiên bản 1.6.22, build 10622.
