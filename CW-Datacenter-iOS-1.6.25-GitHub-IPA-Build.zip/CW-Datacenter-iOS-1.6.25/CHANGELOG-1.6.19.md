# CW Datacenter iOS 1.6.19

- Tăng khối Camera Backup từ 256 KiB lên 4 MiB để giảm 16 lần số request, file handle và tải CPU Host.
- Vẫn giữ upload tuần tự, resume theo offset và chỉ hoàn tất sau khi Host xác nhận đủ file.
- Phiên bản trong app là 1.6.19 (10619); tên IPA giữ tương thích `CW-Datacenter-iOS-1.4.0-unsigned.ipa`.
