# CW Datacenter iOS 1.6.22

- Đồng bộ vị trí xem video với Host và các thiết bị khác mỗi 15 giây.
- Khi mở video, ưu tiên khôi phục vị trí mới nhất từ Host; dữ liệu cục bộ vẫn được dùng khi mất mạng.
- Tab Tổng quan lấy tối đa 5 video đang xem dở từ Host và hiển thị `Tiếp tục từ mm:ss`.
- Danh sách phát giữ `path` và `pool` của từng video để tiến độ không bị gán nhầm khi chuyển video.
- Cập nhật workflow `build-ipa.yml` cho phiên bản 1.6.22 (build 10622).
