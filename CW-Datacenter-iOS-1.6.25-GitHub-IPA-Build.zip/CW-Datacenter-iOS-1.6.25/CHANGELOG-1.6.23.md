# CW Datacenter iOS 1.6.23

- Đưa nút Mở lên đầu: thư mục mở trực tiếp, tệp tự tải rồi mở bằng ứng dụng iOS phù hợp.
- Bổ sung cầu nối Open in native và thông báo “File không hỗ trợ” khi không có ứng dụng nhận tệp.
- Đổi icon ZIP/RAR thành biểu tượng ba lớp nén và APK thành biểu tượng robot Android cách điệu.
- Cập nhật workflow IPA lên phiên bản 1.6.23, build 10623.
