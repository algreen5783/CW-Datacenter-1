# CW Datacenter iOS 1.6.18

- Sửa lỗi Swift `invalid redeclaration of 'deinit'` trong `ImageViewController.swift`.
- Gộp việc hủy bộ hẹn giờ ẩn thanh điều khiển và xóa cache ảnh vào một `deinit` duy nhất.
- Giữ workflow ổn định và artifact chẩn đoán từ 1.6.17.
- Phiên bản trong app là 1.6.18 (10618); tên IPA vẫn giữ tương thích `CW-Datacenter-iOS-1.4.0-unsigned.ipa`.
