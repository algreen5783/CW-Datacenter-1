import UIKit
import Photos

/// Memory-only cache shared by every page in one photo-viewer session.
/// It coalesces duplicate requests and is explicitly cleared when the viewer closes.
fileprivate final class PhotoViewerSessionCache {
    private struct InFlight {
        let task: URLSessionDataTask
        var completions: [(Data?) -> Void]
    }

    private let cache = NSCache<NSString, NSData>()
    private let lock = NSLock()
    private var inFlight: [String: InFlight] = [:]

    init() {
        cache.totalCostLimit = 128 * 1024 * 1024
        cache.countLimit = 9
    }

    func cachedData(for urlString: String) -> Data? {
        return cache.object(forKey: urlString as NSString) as Data?
    }

    func load(urlString: String, completion: @escaping (Data?) -> Void) {
        if let data = cachedData(for: urlString) {
            completion(data)
            return
        }
        guard let url = URL(string: urlString) else {
            completion(nil)
            return
        }

        lock.lock()
        if var running = inFlight[urlString] {
            running.completions.append(completion)
            inFlight[urlString] = running
            lock.unlock()
            return
        }
        lock.unlock()

        var request = URLRequest(url: url)
        if !LocalProxy.shared.token.isEmpty && !url.isFileURL {
            request.setValue("Bearer " + LocalProxy.shared.token, forHTTPHeaderField: "Authorization")
        }

        var task: URLSessionDataTask!
        task = URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            guard let self = self else { return }
            let status = (response as? HTTPURLResponse)?.statusCode ?? 200
            let validData = (error == nil && (200...299).contains(status)) ? data : nil
            if let validData = validData {
                self.cache.setObject(validData as NSData, forKey: urlString as NSString, cost: validData.count)
            }
            self.lock.lock()
            let callbacks = self.inFlight.removeValue(forKey: urlString)?.completions ?? []
            self.lock.unlock()
            callbacks.forEach { $0(validData) }
        }

        lock.lock()
        inFlight[urlString] = InFlight(task: task, completions: [completion])
        lock.unlock()
        task.resume()
    }

    func clear() {
        lock.lock()
        let tasks = inFlight.values.map { $0.task }
        inFlight.removeAll()
        lock.unlock()
        tasks.forEach { $0.cancel() }
        cache.removeAllObjects()
    }
}

class ImageViewController: UIViewController, UIPageViewControllerDataSource, UIPageViewControllerDelegate, UIGestureRecognizerDelegate {

    private var playlist: [[String: Any]]
    private var currentIndex: Int
    private var pageViewController: UIPageViewController!
    private let imageCache = PhotoViewerSessionCache()
    private let prefetchRadius = 4

    private let topBar = UIView()
    private let closeBtn = UIButton(type: .system)
    private let titleLabel = UILabel()
    private let counterLabel = UILabel()
    private let shareBtn = UIButton(type: .system)
    private let bottomBar = UIVisualEffectView(effect: UIBlurEffect(style: .systemThinMaterialDark))
    private let favoriteBtn = UIButton(type: .system)
    private let downloadBtn = UIButton(type: .system)
    private let deleteBtn = UIButton(type: .system)
    private var controlsVisible = true
    private var controlsHideWorkItem: DispatchWorkItem?

    var onFavorite: (([String: Any], @escaping (Bool) -> Void) -> Void)?
    var onDownload: (([String: Any], @escaping (Bool, String?) -> Void) -> Void)?
    var onDelete: (([String: Any], @escaping (Bool, String?) -> Void) -> Void)?

    init(playlist: [[String: Any]], initialIndex: Int) {
        self.playlist = playlist.isEmpty ? [["name": "Hình ảnh", "url": ""]] : playlist
        self.currentIndex = max(0, min(initialIndex, playlist.count - 1))
        super.init(nibName: nil, bundle: nil)
    }

    convenience init(url: String, name: String) {
        self.init(playlist: [["name": name, "url": url]], initialIndex: 0)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        setupPageViewController()
        setupTopBar()
        setupBottomBar()
        setupControlsGesture()
        updateHeaderInfo(for: currentIndex)
        prefetchImages(around: currentIndex)
        showControlsTemporarily()
    }

    private func setupControlsGesture() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(onViewerTapped))
        tap.cancelsTouchesInView = false
        tap.delegate = self
        view.addGestureRecognizer(tap)
    }

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        var candidate: UIView? = touch.view
        while let current = candidate {
            if current is UIControl { return false }
            candidate = current.superview
        }
        return true
    }

    @objc private func onViewerTapped() {
        if controlsVisible {
            setControlsVisible(false)
        } else {
            showControlsTemporarily()
        }
    }

    private func showControlsTemporarily() {
        setControlsVisible(true)
        controlsHideWorkItem?.cancel()
        let item = DispatchWorkItem { [weak self] in self?.setControlsVisible(false) }
        controlsHideWorkItem = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: item)
    }

    private func setControlsVisible(_ visible: Bool) {
        controlsVisible = visible
        if !visible { controlsHideWorkItem?.cancel() }
        topBar.isUserInteractionEnabled = visible
        bottomBar.isUserInteractionEnabled = visible
        UIView.animate(withDuration: 0.2) {
            self.topBar.alpha = visible ? 1 : 0
            self.bottomBar.alpha = visible ? 1 : 0
            self.topBar.transform = visible ? .identity : CGAffineTransform(translationX: 0, y: -18)
            self.bottomBar.transform = visible ? .identity : CGAffineTransform(translationX: 0, y: 18)
        }
    }

    private func setupBottomBar() {
        bottomBar.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.layer.cornerRadius = 20
        bottomBar.clipsToBounds = true
        view.addSubview(bottomBar)

        configureActionButton(favoriteBtn, title: "Yêu thích", symbol: "heart", action: #selector(onFavoriteTapped))
        configureActionButton(downloadBtn, title: "Tải về", symbol: "arrow.down.to.line", action: #selector(onDownloadTapped))
        configureActionButton(deleteBtn, title: "Xóa", symbol: "trash", action: #selector(onDeleteTapped))
        deleteBtn.tintColor = .systemRed

        let stack = UIStackView(arrangedSubviews: [favoriteBtn, downloadBtn, deleteBtn])
        stack.axis = .horizontal
        stack.distribution = .fillEqually
        stack.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.contentView.addSubview(stack)

        NSLayoutConstraint.activate([
            bottomBar.leadingAnchor.constraint(greaterThanOrEqualTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 18),
            bottomBar.trailingAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -18),
            bottomBar.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            bottomBar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -12),
            bottomBar.widthAnchor.constraint(lessThanOrEqualToConstant: 430),
            bottomBar.heightAnchor.constraint(equalToConstant: 70),
            stack.leadingAnchor.constraint(equalTo: bottomBar.contentView.leadingAnchor, constant: 8),
            stack.trailingAnchor.constraint(equalTo: bottomBar.contentView.trailingAnchor, constant: -8),
            stack.topAnchor.constraint(equalTo: bottomBar.contentView.topAnchor, constant: 6),
            stack.bottomAnchor.constraint(equalTo: bottomBar.contentView.bottomAnchor, constant: -6)
        ])
    }

    private func configureActionButton(_ button: UIButton, title: String, symbol: String, action: Selector) {
        let image = UIImage(systemName: symbol)

        if #available(iOS 15.0, *) {
            var config = UIButton.Configuration.plain()
            config.image = image
            config.title = title
            config.imagePlacement = .top
            config.imagePadding = 5
            config.baseForegroundColor = .white
            config.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { incoming in
                var outgoing = incoming
                outgoing.font = UIFont.systemFont(ofSize: 12, weight: .medium)
                return outgoing
            }
            button.configuration = config
        } else {
            // UIButton.Configuration is only available from iOS 15. Keep the
            // image viewer usable on the app's iOS 14 deployment target.
            button.setImage(image, for: .normal)
            button.setTitle(title, for: .normal)
            button.setTitleColor(.white, for: .normal)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 12, weight: .medium)
            button.titleLabel?.textAlignment = .center
            button.contentHorizontalAlignment = .center
            button.imageEdgeInsets = UIEdgeInsets(top: -18, left: 0, bottom: 0, right: -18)
            button.titleEdgeInsets = UIEdgeInsets(top: 26, left: -18, bottom: 0, right: 0)
        }

        button.tintColor = .white
        button.addTarget(self, action: action, for: .touchUpInside)
    }

    private func setupPageViewController() {
        pageViewController = UIPageViewController(
            transitionStyle: .scroll,
            navigationOrientation: .horizontal,
            options: [UIPageViewController.OptionsKey.interPageSpacing: 16]
        )
        pageViewController.dataSource = self
        pageViewController.delegate = self

        let initialVC = singlePhotoVC(for: currentIndex)
        pageViewController.setViewControllers([initialVC], direction: .forward, animated: false, completion: nil)

        addChild(pageViewController)
        view.addSubview(pageViewController.view)
        pageViewController.view.frame = view.bounds
        pageViewController.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        pageViewController.didMove(toParent: self)
    }

    private func setupTopBar() {
        topBar.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        topBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(topBar)

        closeBtn.setTitle("✕", for: .normal)
        closeBtn.setTitleColor(.white, for: .normal)
        closeBtn.titleLabel?.font = UIFont.systemFont(ofSize: 22, weight: .bold)
        closeBtn.addTarget(self, action: #selector(onCloseTapped), for: .touchUpInside)
        closeBtn.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(closeBtn)

        titleLabel.textColor = .white
        titleLabel.font = UIFont.systemFont(ofSize: 14, weight: .semibold)
        titleLabel.textAlignment = .left
        titleLabel.lineBreakMode = .byTruncatingMiddle
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(titleLabel)

        counterLabel.textColor = UIColor.white.withAlphaComponent(0.8)
        counterLabel.font = UIFont.monospacedDigitSystemFont(ofSize: 12, weight: .regular)
        counterLabel.textAlignment = .left
        counterLabel.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(counterLabel)

        shareBtn.setTitle("Chia sẻ", for: .normal)
        shareBtn.setTitleColor(.white, for: .normal)
        shareBtn.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
        shareBtn.backgroundColor = UIColor.white.withAlphaComponent(0.18)
        shareBtn.layer.cornerRadius = 6
        shareBtn.addTarget(self, action: #selector(onShareTapped), for: .touchUpInside)
        shareBtn.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(shareBtn)

        NSLayoutConstraint.activate([
            topBar.topAnchor.constraint(equalTo: view.topAnchor),
            topBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            topBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            topBar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 54),

            closeBtn.leadingAnchor.constraint(equalTo: topBar.leadingAnchor, constant: 14),
            closeBtn.bottomAnchor.constraint(equalTo: topBar.bottomAnchor, constant: -10),
            closeBtn.widthAnchor.constraint(equalToConstant: 36),
            closeBtn.heightAnchor.constraint(equalToConstant: 36),

            titleLabel.leadingAnchor.constraint(equalTo: closeBtn.trailingAnchor, constant: 10),
            titleLabel.topAnchor.constraint(equalTo: closeBtn.topAnchor, constant: -2),
            titleLabel.trailingAnchor.constraint(lessThanOrEqualTo: shareBtn.leadingAnchor, constant: -10),

            counterLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            counterLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 2),

            shareBtn.trailingAnchor.constraint(equalTo: topBar.trailingAnchor, constant: -14),
            shareBtn.centerYAnchor.constraint(equalTo: closeBtn.centerYAnchor),
            shareBtn.widthAnchor.constraint(equalToConstant: 68),
            shareBtn.heightAnchor.constraint(equalToConstant: 30)
        ])
    }

    private func updateHeaderInfo(for index: Int) {
        guard index >= 0 && index < playlist.count else { return }
        let item = playlist[index]
        titleLabel.text = (item["name"] as? String) ?? "Hình ảnh"
        counterLabel.text = "\(index + 1) / \(playlist.count)"
        let isFavorite = item["favorite"] as? Bool ?? false
        let image = UIImage(systemName: isFavorite ? "heart.fill" : "heart")
        if #available(iOS 15.0, *) {
            var configuration = favoriteBtn.configuration
            configuration?.image = image
            favoriteBtn.configuration = configuration
        } else {
            favoriteBtn.setImage(image, for: .normal)
        }
        favoriteBtn.tintColor = isFavorite ? .systemPink : .white
    }

    private func singlePhotoVC(for index: Int) -> SinglePhotoViewController {
        let item = playlist[index]
        let url = (item["url"] as? String) ?? ""
        let localPath = (item["localPath"] as? String) ?? ""
        return SinglePhotoViewController(index: index, urlString: url, localPath: localPath, imageCache: imageCache)
    }

    private func prefetchImages(around index: Int) {
        guard !playlist.isEmpty else { return }
        let lower = max(0, index - prefetchRadius)
        let upper = min(playlist.count - 1, index + prefetchRadius)
        for candidate in lower...upper where candidate != index {
            let item = playlist[candidate]
            let localPath = item["localPath"] as? String ?? ""
            guard localPath.isEmpty, let url = item["url"] as? String, !url.isEmpty else { continue }
            imageCache.load(urlString: url) { _ in }
        }
    }

    // MARK: - UIPageViewControllerDataSource
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let photoVC = viewController as? SinglePhotoViewController else { return nil }
        let prevIndex = photoVC.index - 1
        guard prevIndex >= 0 else { return nil }
        return singlePhotoVC(for: prevIndex)
    }

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let photoVC = viewController as? SinglePhotoViewController else { return nil }
        let nextIndex = photoVC.index + 1
        guard nextIndex < playlist.count else { return nil }
        return singlePhotoVC(for: nextIndex)
    }

    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if completed, let currentVC = pageViewController.viewControllers?.first as? SinglePhotoViewController {
            currentIndex = currentVC.index
            updateHeaderInfo(for: currentIndex)
            prefetchImages(around: currentIndex)
            showControlsTemporarily()
        }
    }

    deinit {
        controlsHideWorkItem?.cancel()
        imageCache.clear()
    }

    @objc private func onShareTapped() {
        guard currentIndex >= 0 && currentIndex < playlist.count else { return }
        let item = playlist[currentIndex]
        let localPath = item["localPath"] as? String ?? ""
        if !localPath.isEmpty && FileManager.default.fileExists(atPath: localPath) {
            let fileUrl = URL(fileURLWithPath: localPath)
            let avc = UIActivityViewController(activityItems: [fileUrl], applicationActivities: nil)
            present(avc, animated: true)
            return
        }
        guard let urlStr = item["url"] as? String, let url = URL(string: urlStr) else { return }
        if let data = imageCache.cachedData(for: urlStr), let image = UIImage(data: data) {
            let avc = UIActivityViewController(activityItems: [image], applicationActivities: nil)
            present(avc, animated: true)
            return
        }
        var req = URLRequest(url: url)
        if !LocalProxy.shared.token.isEmpty && !url.isFileURL {
            req.setValue("Bearer " + LocalProxy.shared.token, forHTTPHeaderField: "Authorization")
        }
        URLSession.shared.dataTask(with: req) { [weak self] data, _, _ in
            guard let d = data, let img = UIImage(data: d) else { return }
            DispatchQueue.main.async {
                let avc = UIActivityViewController(activityItems: [img], applicationActivities: nil)
                self?.present(avc, animated: true)
            }
        }.resume()
    }

    @objc private func onFavoriteTapped() {
        guard playlist.indices.contains(currentIndex) else { return }
        let item = playlist[currentIndex]
        favoriteBtn.isEnabled = false
        onFavorite?(item) { [weak self] value in
            DispatchQueue.main.async {
                guard let self = self, self.playlist.indices.contains(self.currentIndex) else { return }
                self.playlist[self.currentIndex]["favorite"] = value
                self.favoriteBtn.isEnabled = true
                self.updateHeaderInfo(for: self.currentIndex)
            }
        }
    }

    @objc private func onDownloadTapped() {
        guard playlist.indices.contains(currentIndex) else { return }
        downloadBtn.isEnabled = false
        onDownload?(playlist[currentIndex]) { [weak self] ok, message in
            DispatchQueue.main.async {
                self?.downloadBtn.isEnabled = true
                self?.showResult(message ?? (ok ? "Đã lưu ảnh vào Thư viện ảnh." : "Không lưu được ảnh."), success: ok)
            }
        }
    }

    @objc private func onDeleteTapped() {
        guard playlist.indices.contains(currentIndex) else { return }
        let item = playlist[currentIndex]
        let name = item["name"] as? String ?? "ảnh này"
        let alert = UIAlertController(title: "Xóa \(name)?", message: "Ảnh sẽ được chuyển vào Thùng rác trên Host.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Hủy", style: .cancel))
        alert.addAction(UIAlertAction(title: "Xóa", style: .destructive) { [weak self] _ in
            guard let self = self else { return }
            self.deleteBtn.isEnabled = false
            self.onDelete?(item) { [weak self] ok, message in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    self.deleteBtn.isEnabled = true
                    guard ok else { self.showResult(message ?? "Không xóa được ảnh.", success: false); return }
                    self.playlist.remove(at: self.currentIndex)
                    if self.playlist.isEmpty { self.dismiss(animated: true); return }
                    self.currentIndex = min(self.currentIndex, self.playlist.count - 1)
                    let next = self.singlePhotoVC(for: self.currentIndex)
                    self.pageViewController.setViewControllers([next], direction: .forward, animated: true, completion: nil)
                    self.updateHeaderInfo(for: self.currentIndex)
                    self.prefetchImages(around: self.currentIndex)
                    self.showResult(message ?? "Đã chuyển ảnh vào Thùng rác.", success: true)
                }
            }
        })
        present(alert, animated: true)
    }

    private func showResult(_ message: String, success: Bool) {
        let alert = UIAlertController(title: success ? "Hoàn tất" : "Có lỗi", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Đóng", style: .default))
        present(alert, animated: true)
    }

    @objc private func onCloseTapped() {
        imageCache.clear()
        dismiss(animated: true)
    }

}

class SinglePhotoViewController: UIViewController, UIScrollViewDelegate {
    let index: Int
    let urlString: String
    let localPath: String
    private let imageCache: PhotoViewerSessionCache

    private var scrollView: UIScrollView!
    private var imageView: UIImageView!
    private var spinner: UIActivityIndicatorView!

    fileprivate init(index: Int, urlString: String, localPath: String, imageCache: PhotoViewerSessionCache) {
        self.index = index
        self.urlString = urlString
        self.localPath = localPath
        self.imageCache = imageCache
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear

        scrollView = UIScrollView(frame: view.bounds)
        scrollView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        scrollView.delegate = self
        scrollView.minimumZoomScale = 1.0
        scrollView.maximumZoomScale = 4.0
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        view.addSubview(scrollView)

        imageView = UIImageView(frame: scrollView.bounds)
        imageView.contentMode = .scaleAspectFit
        imageView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        imageView.isUserInteractionEnabled = true
        scrollView.addSubview(imageView)

        spinner = UIActivityIndicatorView(style: .large)
        spinner.color = .white
        spinner.center = view.center
        spinner.hidesWhenStopped = true
        view.addSubview(spinner)

        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(onDoubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        view.addGestureRecognizer(doubleTap)

        loadImage()
    }

    private func loadImage() {
        if !localPath.isEmpty && FileManager.default.fileExists(atPath: localPath) {
            if let img = UIImage(contentsOfFile: localPath) {
                imageView.image = img
                return
            }
        }
        guard URL(string: urlString) != nil else { return }
        spinner.startAnimating()

        imageCache.load(urlString: urlString) { [weak self] data in
            DispatchQueue.main.async {
                self?.spinner.stopAnimating()
                if let d = data, let img = UIImage(data: d) {
                    self?.imageView.image = img
                }
            }
        }
    }

    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return imageView
    }

    @objc private func onDoubleTap(_ gesture: UITapGestureRecognizer) {
        if scrollView.zoomScale > 1.0 {
            scrollView.setZoomScale(1.0, animated: true)
        } else {
            let point = gesture.location(in: imageView)
            let rect = CGRect(x: point.x - 60, y: point.y - 60, width: 120, height: 120)
            scrollView.zoom(to: rect, animated: true)
        }
    }
}
