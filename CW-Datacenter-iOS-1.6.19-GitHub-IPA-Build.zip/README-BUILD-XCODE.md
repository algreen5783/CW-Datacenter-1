# Build CW Datacenter iOS 1.6.19

## Build IPA bằng GitHub Actions

1. Upload `CW-Datacenter-iOS-1.6.19-GitHub-IPA-Build.zip` vào thư mục gốc repository.
2. Giữ file `.github/workflows/build-ipa.yml` của gói này trong repository.
3. Mở **Actions** > **Build CW Datacenter iOS 1.6.19 IPA** > **Run workflow**.
4. Tải artifact `CW-Datacenter-iOS-1.4.0-unsigned` khi job hoàn tất.

Tên IPA vẫn là `CW-Datacenter-iOS-1.4.0-unsigned.ipa` để tương thích quy trình cũ. Phiên bản thật bên trong app là `1.6.19` (build `10619`).

Workflow đã được sửa để:

- tự giải nén đúng ZIP 1.6.19;
- chỉ định đích build `generic/platform=iOS`;
- tách bước clean và build;
- build tuần tự một worker để tránh Xcode 16.4 dừng đột ngột khi xử lý app và Share Extension;
- tắt index store/validate không cần thiết cho IPA unsigned;
- luôn lưu `xcodebuild.log` và `CWDatacenter.xcresult` trong artifact chẩn đoán nếu Xcode còn lỗi.

## Kiểm tra bắt buộc

- App: `1.6.19` (`10619`).
- Bundle chứa `Web/index.html`, `Web/app.js` và `PlugIns/CWDatacenterShare.appex`.
- IPA tạo bởi workflow là unsigned và cần được ký trước khi cài lên iPhone.
