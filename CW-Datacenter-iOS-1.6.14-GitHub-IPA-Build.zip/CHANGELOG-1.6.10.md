# CW Datacenter iOS 1.6.10

- Tab Đồng bộ luôn tải lại cấu hình ổ Camera mới nhất từ Host.
- Tự tạo thư mục theo tên thiết bị trên ổ Camera mới nếu chưa tồn tại.
- Không còn đoán cố định ổ E: khi Host đã cung cấp `pool_camera`.
- Không coi lỗi thư mục hoặc quyền truy cập là lỗi mất kết nối.

Phiên bản 1.6.10, build 10610.
