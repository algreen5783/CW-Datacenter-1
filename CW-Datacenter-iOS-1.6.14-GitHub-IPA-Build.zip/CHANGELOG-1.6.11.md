# CW Datacenter iOS 1.6.11

- Tải lên mọi loại tệp dung lượng lớn theo từng đoạn 1 MiB, tối đa 8 lần thử lại với backoff.
- Tiếp tục upload theo offset Host xác nhận; tự khôi phục phiên bị mất mà không nạp cả tệp vào RAM.
- Tải xuống theo Range 32 MiB và lưu `.cwpart` bền vững trong Application Support để bấm thử lại tiếp tục phần còn thiếu.
- Xác minh `Content-Range`, offset và tổng dung lượng trước khi đổi tệp tạm thành tệp hoàn chỉnh.
- Đồng bộ ảnh/video PhotoKit tăng số lần retry và số lần phục hồi phiên từ 3 lên 8.
- Chế độ danh sách dạng lưới hỗ trợ nhấn giữ để chọn nhiều file/thư mục, sau đó Copy, Cut, Xóa hoặc dùng tác vụ hàng loạt.
- Giữ nguyên tên artifact IPA cũ `CW-Datacenter-iOS-1.4.0-unsigned.ipa` để tương thích repository GitHub hiện có.
