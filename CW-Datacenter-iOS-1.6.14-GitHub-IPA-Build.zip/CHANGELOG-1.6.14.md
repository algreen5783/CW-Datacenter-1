# CW Datacenter iOS 1.6.14

- Sửa SVG trong popup Chọn ổ đĩa bị phóng to và đè lên nội dung.
- Khóa icon trong khung 52 px, kích thước hình vẽ 28 px và không cho tràn khỏi thẻ ổ đĩa.
